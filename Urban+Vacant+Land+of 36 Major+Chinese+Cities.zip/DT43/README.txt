To use the data, please cite the original source at https://data.mendeley.com/datasets/3c8myvygjj.

----------------------------------------------------
This is the supplementary data to the paper "Large-scale Automatic Identification of Urban Vacant Land Using Semantic Segmentation of High-Resolution Remote Sensing Images", which shows the identification results in 36 major cities in China.

The files include the shapefiles of the vacant land and the boundary of each city. The filename formats are as follows:
(1) vacant land: [abbr. of city name]_VL
(2) boundary:  [abbr. of city name]_BD

The abbreviations of the city name are as follows:
abbr.	city name
BJ	Beijing
CC	Changchun
CD	Chengdu
CQ	Chongqing
CS	Changsha
DL	Dalian
FZ	Fuzhou
GY	Guiyang
GZ	Guangzhou
HE	Harbin
HF	Hefei
HH	Hohhot
HK	Haikou
HZ	Hangzhou
JN	Jinan
KM	Kunming
LS	Lhasa
LZ	Lanzhou
NB	Ningbo
NC	Nanchang
NJ	Nanjing
NN	Nanning
QD	Qingdao
SH	Shanghai
SJ	Shijiazhuang
SY	Shenyang
SZ	Shenzhen
TJ	Tianjin
TY	Taiyuan
WH	Wuhan
WL	Urumqi
XA	Xi’an
XM	Xiamen
XN	Xining
YC	Yinchuan
ZZ	Zhengzhou

To reproduce the data, one can refer to the paper "Large-scale Automatic Identification of Urban Vacant Land Using Semantic Segmentation of High-Resolution Remote Sensing Images". 

The code is available at https://github.com/SkydustZ/Large-scale-Automatic-Identification-of-Urban-Vacant-Land.